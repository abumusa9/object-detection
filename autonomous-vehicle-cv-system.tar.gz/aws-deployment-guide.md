# AWS Deployment Guide - Computer Vision System

## Prerequisites

1. **AWS Account**: Sign up for AWS Free Tier
2. **EC2 Instance**: Launch a t2.micro or t3.micro instance (Free Tier eligible)
3. **Docker**: Install Docker on your EC2 instance

## Step 1: Launch EC2 Instance

1. Go to AWS EC2 Console
2. Click "Launch Instance"
3. Choose **Amazon Linux 2** or **Ubuntu 20.04 LTS** (Free Tier eligible)
4. Select **t2.micro** instance type (Free Tier eligible)
5. Configure Security Group:
   - Allow SSH (port 22) from your IP
   - Allow HTTP (port 80) from anywhere (0.0.0.0/0)
   - Allow Custom TCP (port 5000) from anywhere (0.0.0.0/0)
6. Create or select a key pair
7. Launch the instance

## Step 2: Connect to EC2 Instance

```bash
ssh -i your-key.pem ec2-user@your-instance-public-ip
# or for Ubuntu:
ssh -i your-key.pem ubuntu@your-instance-public-ip
```

## Step 3: Install Docker

### For Amazon Linux 2:
```bash
sudo yum update -y
sudo yum install -y docker
sudo service docker start
sudo usermod -a -G docker ec2-user
```

### For Ubuntu:
```bash
sudo apt update
sudo apt install -y docker.io
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker ubuntu
```

Log out and log back in for group changes to take effect.

## Step 4: Upload Application

### Option A: Using SCP
```bash
# From your local machine
scp -i your-key.pem -r cv_backend/ ec2-user@your-instance-public-ip:~/
```

### Option B: Using Git
```bash
# On EC2 instance
git clone <your-repository-url>
cd cv_backend
```

## Step 5: Deploy Application

```bash
cd cv_backend
./deploy.sh
```

## Step 6: Configure Reverse Proxy (Optional)

Install and configure Nginx to serve on port 80:

```bash
# Install Nginx
sudo yum install -y nginx  # Amazon Linux
# or
sudo apt install -y nginx  # Ubuntu

# Create Nginx config
sudo tee /etc/nginx/conf.d/cv-backend.conf << EOF
server {
    listen 80;
    server_name _;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Start Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

## Step 7: Access Your Application

- Direct access: `http://your-instance-public-ip:5000`
- With Nginx: `http://your-instance-public-ip`

## Monitoring and Maintenance

### Check Application Status
```bash
docker ps
docker logs cv-backend
```

### Update Application
```bash
cd cv_backend
git pull  # if using git
./deploy.sh
```

### Monitor Resource Usage
```bash
docker stats cv-backend
free -h
df -h
```

## Cost Optimization Tips

1. **Use t2.micro**: Stays within Free Tier limits
2. **Monitor usage**: Keep track of your Free Tier usage
3. **Stop when not needed**: Stop EC2 instance when not in use
4. **Use minimal Docker image**: Our Dockerfile is already optimized
5. **Clean up unused images**: `docker system prune -a`

## Troubleshooting

### Container Won\'t Start
```bash
docker logs cv-backend
```

### Out of Memory
```bash
# Check memory usage
free -h
# Restart with lower memory limit
docker run --memory=\"512m\" ...
```

### Port Issues
```bash
# Check if port is in use
sudo netstat -tlnp | grep :5000
# Check security group settings in AWS Console
```

## Security Considerations

1. **Restrict SSH access**: Only allow your IP in security group
2. **Use HTTPS**: Consider using Let\'s Encrypt for SSL
3. **Regular updates**: Keep system and Docker updated
4. **Firewall**: Configure iptables if needed
5. **Monitoring**: Set up CloudWatch for monitoring

## Scaling Beyond Free Tier

When ready to scale:
1. Upgrade to larger instance types (t3.small, t3.medium)
2. Use Application Load Balancer
3. Implement auto-scaling groups
4. Use RDS for database (if needed)
5. Consider ECS or EKS for container orchestration

